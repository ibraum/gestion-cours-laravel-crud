;
<?php $__env->startSection('content'); ?>;
<h3 class="mt-5">Listes des cours</h3>
<div class="row justify-content-center text-center mt-3">
    <div class="col-md-12">
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        <div class="card border border-3">
            <div class="card-header">
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('cours.create')); ?>" class="btn btn-success btn-sn my-2">
                    <i class="bi bi-plus-circle"></i>
                    Ajouter cours
                </a>
                <table class="table table-striped table-bordered bg-warning">
                    <thead>
                    <tr>
                        <th>Nbr de cours</th>
                        <th>Id</th>
                        <th>Nom</th>
                        <th>Professeur</th>
                        <th>Heures</th>
                        <th>Crédits</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($cour->id); ?></td>
                            <td><?php echo e($cour->libelCour); ?></td>
                            <td><?php echo e($cour->professeur); ?></td>
                            <td><?php echo e($cour->heures); ?></td>
                            <td><?php echo e($cour->credit); ?></td>
                            <td>
                                <form action="<?php echo e(route('cours.destroy', $cour->id)); ?>" method="post" class="d-flex justify-content-between">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <a href="<?php echo e(route('cours.show', $cour->id)); ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-eye"></i>&nbsp;&nbsp;Show
                                    </a>

                                    <a href="<?php echo e(route('cours.edit', $cour->id)); ?>" class="btn btn-primary btn-sm">
                                        <i class="bi bi-pencil-square"></i>&nbsp;&nbsp;Edit
                                    </a>

                                    <button type="submit" onclick="return confirm('Voulez-vous supprimer ce cour ?')" class="btn btn-danger btn-sm" value="Delete">
                                        <i class="bi bi-trash"></i>&nbsp;&nbsp;Delete
                                    </button>

                                    <a href="<?php echo e(route('cours.showEtudiants', $cour->id)); ?>" class="btn btn-success btn-sm">
                                        <i class="bi bi-person"></i>&nbsp;&nbsp;Etudiants
                                    </a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9">
                                        <span class="text-danger">
                                            Pas de cours trouvé !
                                        </span>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($cours->links()); ?>

            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\laravel_php_ajax_groupe_11_gestion_cours\gestion_cours\resources\views/cours/index.blade.php ENDPATH**/ ?>