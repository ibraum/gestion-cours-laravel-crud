;
<?php $__env->startSection('content'); ?>;
<div class="row justify-content-center text-center mt-3">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <div class="float-start text-start">
                     <div class="fs-5 fw-bold">Information sur l'étudiant</div>
                </div>
                <div class="float-end">
                    <a href="<?php echo e(route('etudiants.index')); ?>" class="btn btn-primary btn-sm">
                        &larr; back
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <label for="nomEtu" class="col-md-4 col-form-label text-end">
                        <strong>Nom </strong>
                    </label>
                    <div class="col-md-6 text-end" style="line-height: 35px;">
                        <?php echo e($etudiant->nomEtu); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="prenomEtu" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Prénom </strong>
                    </label>
                    <div class="col-md-6 text-end" style="line-height: 35px;">
                        <?php echo e($etudiant->prenomEtu); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="dateNaiss" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Date de naissance </strong>
                    </label>
                    <div class="col-md-6 text-end" style="line-height: 35px;">
                        <?php echo e($etudiant->dateNaiss); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="sexe" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Sexe </strong>
                    </label>
                    <div class="col-md-6 text-end" style="line-height: 35px;">
                        <?php echo e($etudiant->sexe); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="email" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Email </strong>
                    </label>
                    <div class="col-md-6 text-end" style="line-height: 35px;">
                        <?php echo e($etudiant->email); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="localite" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Localité </strong>
                    </label>
                    <div class="col-md-6 text-end" style="line-height: 35px;">
                        <?php echo e($etudiant->localite); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="tel" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Téléphone </strong>
                    </label>
                    <div class="col-md-6 text-end" style="line-height: 35px;">
                        <?php echo e($etudiant->tel); ?>

                    </div>
                </div>

                <a href="<?php echo e(route("etudiantcours.addCour", $etudiant->id)); ?>" class="btn btn-primary btn-sm float-end">
                    Ajouter un ou des cours
                </a>

            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\laravel_php_ajax_groupe_11_gestion_cours\gestion_cours\resources\views/etudiants/show.blade.php ENDPATH**/ ?>