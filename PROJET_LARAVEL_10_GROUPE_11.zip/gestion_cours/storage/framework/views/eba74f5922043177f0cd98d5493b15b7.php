;
<?php $__env->startSection('content'); ?>
    ;

    <div class="row justify-content-center mt-3">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="float-start">
                        Ajout nouveau cour
                    </div>
                    <div class="float-end">
                        <a href="<?php echo e(route('cours.index')); ?>" class="btn btn-success btn-sm">&larr; retour </a>
                    </div>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('cours.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3 row">
                            <label for="libelCour" class="col-md-4 col-form-label text-md-end text-start">
                                Nom cour
                            </label>
                            <div class="col-md-6">
                                <input type="text" class="form-control <?php $__errorArgs = ['libelCour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="libelCour"
                                       name="libelCour" value="<?php echo e(old('libelCour')); ?>" placeholder="Entrer le libele du cour">
                                <?php if($errors->has('libelCour')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('libelCour')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label for="description" class="col-md-4 col-form-label text-md-end text-start">
                                Description
                            </label>
                            <div class="col-md-6">
                            <textarea type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="description" name="description" placeholder="Description ...">
                                <?php echo e(old('description')); ?>

                            </textarea>
                                <?php if($errors->has('description')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('description')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label for="professeur" class="col-md-4 col-form-label text-md-end text-start">
                                Professeur
                            </label>
                            <div class="col-md-6">
                                <input type="text"
                                       class="form-control <?php $__errorArgs = ['professeur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="professeur"
                                       name="professeur" value="<?php echo e(old('professeur')); ?>" placeholder="Chargé du cour">
                                <?php if($errors->has('professeur')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('professeur')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label for="heures" class="col-md-4 col-form-label text-md-end text-start">
                                Heures
                            </label>
                            <div class="col-md-6">
                                <input type="number"
                                       class="form-control <?php $__errorArgs = ['heures'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="heures"
                                       name="heures" value="<?php echo e(old('heures')); ?>" placeholder="Nombres d'heures">
                                <?php if($errors->has('heures')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('heures')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label for="credit" class="col-md-4 col-form-label text-md-end text-start">
                                Crédit(s)
                            </label>
                            <div class="col-md-6">
                                <input type="number" min="1"
                                       class="form-control <?php $__errorArgs = ['credit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="credit" name="credit"
                                       value="<?php echo e(old('credit')); ?>" placeholder="Nombre de crédit">
                                <?php if($errors->has('credit')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('credit')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <input type="submit" class="col-md-3 offset-md-5 btn btn-success" value="Ajouter le cours">
                        </div>
                    </form>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\laravel_php_ajax_groupe_11_gestion_cours\gestion_cours\resources\views/cours/create.blade.php ENDPATH**/ ?>