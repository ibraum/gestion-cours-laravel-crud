;
<?php $__env->startSection('content'); ?>;
<div class="row justify-content-center text-center mt-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="float-start">
                    Information du cours (<?php echo e($cour->libelCour); ?>)
                </div>
                <div class="float-end">
                    <a href="<?php echo e(route('cours.index')); ?>" class="btn btn-primary btn-sm">
                        &larr; back
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <label for="libelCour" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>libelé du cours </strong>
                    </label>
                    <div class="col-md-6" style="line-height: 35px;">
                        <?php echo e($cour->libelCour); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="professeur" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Professeur </strong>
                    </label>
                    <div class="col-md-6" style="line-height: 35px;">
                        <?php echo e($cour->professeur); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="heures" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Heures: </strong>
                    </label>
                    <div class="col-md-6" style="line-height: 35px;">
                        <?php echo e($cour->heures); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="credit" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Credit: </strong>
                    </label>
                    <div class="col-md-6" style="line-height: 35px;">
                        <?php echo e($cour->credit); ?>

                    </div>
                </div>

                <div class="row">
                    <label for="description" class="col-md-4 col-form-label text-md-end text-start">
                        <strong>Description </strong>
                    </label>
                    <div class="col-md-6" style="line-height: 35px;">
                        <?php echo e($cour->description); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\laravel_php_ajax_groupe_11_gestion_cours\gestion_cours\resources\views/cours/show.blade.php ENDPATH**/ ?>