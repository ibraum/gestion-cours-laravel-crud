.
<?php $__env->startSection('content'); ?>.
<h2 class="mt-1 text-danger">Listes des inscriptions</h2>
<div class="row justify-content-center text-center mt-3">
    <div class="col-md-12">
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        <div class="card border border-3">
            <div class="card-body">
                <table class="table table-striped table-bordered bg-warning">
                    <h3 class="mt-1">Listes des cours</h3>
                    <thead>
                            <tr>
                                <th>Nbr de cours</th>
                                <th>Id</th>
                                <th>Libelé</th>
                                <th>Professeur</th>
                                <th>Heures</th>
                                <th>Crédits</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($cour->id); ?></td>
                                        <td><?php echo e($cour->libelCour); ?></td>
                                        <td><?php echo e($cour->professeur); ?></td>
                                        <td><?php echo e($cour->heures); ?></td>
                                        <td><?php echo e($cour->credit); ?></td>
                                <td>
                                            <form action="<?php echo e(route('etudiants.destroy', $cour->id)); ?>" method="post" class="d-flex justify-content-between">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <a href="<?php echo e(route('etudiants.show', $cour->id)); ?>" class="btn btn-warning btn-sm">
                                                    <i class="bi bi-eye"></i>&nbsp;&nbsp;Show
                                                </a>

                                                <a href="<?php echo e(route('etudiants.edit', $cour->id)); ?>" class="btn btn-primary btn-sm">
                                                    <i class="bi bi-pencil-square"></i>&nbsp;&nbsp;Edit
                                                </a>

                                                <button type="submit" onclick="return confirm('Voulez-vous supprimer ce étudiant ?')" class="btn btn-danger btn-sm" value="Delete">
                                                    <i class="bi bi-trash"></i>&nbsp;&nbsp;Delete
                                                </button>

                                            </form>
                                        </td>
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<div class="row justify-content-center text-center mt-5">
    <div class="col-md-12">
        <div class="card border border-3">
            <div class="card-body">
                <table class="table table-striped table-bordered bg-warning">
                    <h3 class="mt-1 mb-2">Listes des étudiants</h3>
                    <thead>
                    <tr>
                        <th>Numéro</th>
                        <th>Id</th>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Date de naissance</th>
                        <th>Sexe</th>
                        <th>Email</th>
                        <th>Localité</th>
                        <th>Téléphone</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_2 = true; $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($etudiant->id); ?></td>
                            <td><?php echo e($etudiant->nomEtu); ?></td>
                            <td><?php echo e($etudiant->prenomEtu); ?></td>
                            <td><?php echo e($etudiant->dateNaiss); ?></td>
                            <td><?php echo e($etudiant->sexe); ?></td>
                            <td><?php echo e($etudiant->email); ?></td>
                            <td><?php echo e($etudiant->localite); ?></td>
                            <td><?php echo e($etudiant->tel); ?></td>
                            <td>
                                <form action="<?php echo e(route('etudiants.destroy', $etudiant->id)); ?>" method="post" class="d-flex justify-content-between">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <a href="<?php echo e(route('etudiants.show', $etudiant->id)); ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-eye"></i>&nbsp;&nbsp;Show
                                    </a>

                                    <a href="<?php echo e(route('etudiants.edit', $etudiant->id)); ?>" class="btn btn-primary btn-sm">
                                        <i class="bi bi-pencil-square"></i>&nbsp;&nbsp;Edit
                                    </a>

                                    <button type="submit" onclick="return confirm('Voulez-vous supprimer ce étudiant ?')" class="btn btn-danger btn-sm" value="Delete">
                                        <i class="bi bi-trash"></i>&nbsp;&nbsp;Delete
                                    </button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <tr>
                            <td colspan="10">
                                        <span class="text-danger">
                                            Pas d'étudiant trouvé !
                                        </span>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\laravel_php_ajax_groupe_11_gestion_cours\gestion_cours\resources\views/etudiantcours/index.blade.php ENDPATH**/ ?>